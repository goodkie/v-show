/**
 * form-discovery-engine-r2.js
 * [Issue #6 R6.2] Body-Field-First Form Recognition, Multi-Root Collector,
 * Multi-Pass Render Wait, and Autofill Bridge
 * 
 * Capabilities:
 * 1. Accessible Root Collector: Main document, open Shadow DOMs, same-origin iframes,
 *    and cross-origin iframe diagnostic signaling.
 * 2. Body-Field-First Recognition: Discovers inquiry-body controls (textarea, contenteditable,
 *    role=textbox, multiline semantic inputs) and infers upward to nearest coherent logical container
 *    (native <form>, fieldset, section, article, div.contact, etc.).
 * 3. High-Recall Eligibility Gate: A visible inquiry body + at least one contact/identity field
 *    or submit button qualifies; numeric score is strictly for ranking multiple candidates.
 * 4. Multi-Pass Render Wait: Pass 1 immediate, Pass 2 after settle (400-700ms),
 *    Pass 3 after bounded scroll and safe modal/drawer reveal (800-1500ms).
 * 5. Autofill Bridge: Canonical startAutofillForEligibleForm() latching by attemptId + formSignature,
 *    dispatched within 250ms, with precise failure taxonomy.
 * 6. Form Node Rebinding: Detects hydration detached nodes and rebinds by signature.
 */

(function (root, factory) {
    if (typeof define === 'function' && define.amd) {
        define([], factory);
    } else if (typeof module === 'object' && module.exports) {
        module.exports = factory();
    } else {
        const mod = factory();
        root.FormDiscoveryEngineR2 = mod.FormDiscoveryEngineR2;
        root.FormDiscoveryEngine = mod.FormDiscoveryEngineR2; // R6.2 primary alias
    }
}(typeof self !== 'undefined' ? self : this, function () {

    // 1. Inquiry Body Semantic Keywords
    const INQUIRY_BODY_TOKENS = [
        'message', 'inquiry', 'enquiry', 'question', 'comments', 'comment',
        'details', 'description', 'how can we help', 'tell us', 'contact message',
        'your message', 'request', 'notes', 'inquiries', 'feedback',
        '문의', '문의내용', '질문', '메시지', '상담', '상담내용', '요청사항', '내용'
    ];

    const NEWSLETTER_NEGATIVE_TOKENS = [
        'subscribe', 'newsletter', 'mailing list', 'email updates', 'join our list',
        'get updates', 'notify me', 'sign up for updates', 'get offers', '구독', '뉴스레터'
    ];

    const OTHER_NEGATIVE_CONTAINER_TOKENS = [
        'login', 'log in', 'signin', 'sign-in', 'search', '로그인', '검색'
    ];

    const SAFE_REVEAL_KEYWORDS = [
        'contact us', 'send message', 'send us a message', 'message us',
        'get in touch', 'ask a question', 'request info', 'inquiry',
        'contact', '문의하기', '상담신청', '고객센터'
    ];

    const DESTRUCTIVE_OR_UNSAFE_KEYWORDS = [
        'login', 'sign in', 'subscribe', 'newsletter', 'book now', 'booking',
        'pay', 'checkout', 'delete', 'cancel', 'remove', 'reset', 'clear'
    ];

    function resolveContactGate() {
        return (typeof window !== 'undefined' && window.ContactGate) ||
            (typeof global !== 'undefined' && global.ContactGate) ||
            (typeof require !== 'undefined' ? (function () {
                try { return require('./contact-gate.js'); } catch (_) {
                    try { return require('./modules/contact-gate.js'); } catch (__) { return null; }
                }
            })() : null);
    }

    function isVisible(el) {
        if (!el) return false;
        try {
            if (typeof window !== 'undefined' && window.getComputedStyle) {
                const style = window.getComputedStyle(el);
                if (style.display === 'none' || style.visibility === 'hidden' || style.opacity === '0') {
                    return false;
                }
            }
            if (el.hidden || el.type === 'hidden') return false;
            if (el.style && (el.style.display === 'none' || el.style.visibility === 'hidden')) return false;
            if (el.getAttribute && (el.getAttribute('aria-hidden') === 'true')) return false;
            return true;
        } catch (_) {
            return true;
        }
    }

    function isHoneypot(el) {
        if (!el) return false;
        try {
            const name = (el.name || el.id || '').toLowerCase();
            if (name.includes('honeypot') || name.includes('hp_') || name === 'hp') return true;
            if (el.style) {
                if (el.style.position === 'absolute' && (el.style.left === '-9999px' || el.style.top === '-9999px')) return true;
                if (el.style.opacity === '0' && el.tabIndex === -1) return true;
            }
            if (el.getAttribute && el.getAttribute('tabindex') === '-1' && el.getAttribute('aria-hidden') === 'true') return true;
            return false;
        } catch (_) {
            return false;
        }
    }

    // [RC3.60 P0] Exclude Browser-Extension Injected Translation Overlays, Toolbars & Modals
    function isExcludedOverlayElement(el) {
        if (!el) return false;
        try {
            let cur = el;
            while (cur && cur.tagName !== 'BODY' && cur.tagName !== 'HTML') {
                const id = (cur.id || '').toLowerCase();
                const cls = (typeof cur.className === 'string' ? cur.className : (cur.getAttribute?.('class') || '')).toLowerCase();
                const role = (cur.getAttribute ? (cur.getAttribute('role') || '') : '').toLowerCase();
                const tag = (cur.tagName || '').toLowerCase();
                const combined = `${id} ${cls} ${role} ${tag}`;

                // Internal Xpider UI
                if (id.startsWith('xpider-') || cls.includes('xpider-') || id.includes('xpider') || cls.includes('xpider')) return true;

                // Browser extension translation overlays (e.g. default-translate-modal, bigTranslateModal, immersive-translate)
                if (/translate|trans-popup|trans-modal|trans-bubble|trans-container|goog-te|notranslate|skiptranslate|deepl|immersive|kiss-trans/i.test(combined)) {
                    return true;
                }

                // Extension dictionary search / single-word lookup widgets
                if (/singlewordsearch|wordsearch|dictsearch|dictionary|vocab/i.test(combined)) {
                    return true;
                }

                // Third-party browser extension injected toolbars (Grammarly, LastPass, 1Password, Bitwarden, Sider, Monica, Harpa, etc.)
                if (/grammarly|lastpass|1password|bitwarden|sider|monica|harpa|chatgpt-ext|__ext_|chrome-extension|edge-extension|moz-extension/i.test(combined)) {
                    return true;
                }

                // General non-page search drawers / quick-search modals
                if (role === 'search' || cls.includes('search-modal') || cls.includes('search-drawer') || id.includes('site-search')) {
                    return true;
                }

                // Custom element extension roots (e.g. <immersive-translate-container>, <translate-modal>)
                if (tag.includes('-') && (tag.includes('translate') || tag.includes('modal') || tag.includes('ext'))) {
                    return true;
                }

                cur = cur.parentElement;
            }
        } catch (_) { }
        return false;
    }

    // [P0-B & P0-C Fix] Robust 404 / Error Page Guard for Form Discovery
    function isPageErrorOr404(doc = (typeof document !== 'undefined' ? document : null)) {
        if (!doc) return false;
        try {
            const title = (doc.title || '').toLowerCase();
            const body = doc.body;
            if (!body) return false;

            const titleKeywords = [
                '404', 'not found', 'page not found', 'error 404', '404 error',
                'page doesn\'t exist', 'page does not exist', 'cannot be found', 'nothing found',
                '찾을 수 없습니다', '오류 404', '페이지를 찾을 수 없습니다'
            ];
            if (titleKeywords.some(k => title.includes(k))) return true;

            const headings = Array.from(doc.querySelectorAll('h1, h2, h3, .error-title, .not-found'));
            for (const h of headings) {
                const txt = (h.textContent || '').trim().toLowerCase();
                if (txt.length < 120 && (
                    txt.includes('404') ||
                    txt.includes('page not found') ||
                    txt.includes('page cannot be found') ||
                    txt.includes('not found') ||
                    txt.includes('nothing found') ||
                    txt.includes('we couldn\'t find that page') ||
                    txt.includes('페이지를 찾을 수 없습니다')
                )) {
                    return true;
                }
            }

            const bodyText = (body.textContent || '').toLowerCase();
            const strongErrorSignals = [
                '404 not found', '404 - not found', '404: not found', 'error 404',
                'page not found', 'the requested url was not found on this server',
                'the page you are looking for cannot be found',
                'the page you requested could not be found',
                'this page could not be found',
                'sorry, we can\'t find that page',
                'oops! that page can’t be found',
                'oops! that page cannot be found',
                '페이지를 찾을 수 없습니다'
            ];
            if (strongErrorSignals.some(s => bodyText.includes(s))) return true;
        } catch (_) { }
        return false;
    }

    function getControlContext(el) {
        if (!el) return '';
        const parts = [
            el.name || '',
            el.id || '',
            el.getAttribute?.('placeholder') || '',
            el.getAttribute?.('aria-label') || '',
            el.getAttribute?.('aria-describedby') || '',
            el.className || ''
        ];
        try {
            if (el.id && el.ownerDocument && el.ownerDocument.querySelector) {
                const lbl = el.ownerDocument.querySelector(`label[for="${el.id}"]`);
                if (lbl) parts.push(lbl.textContent || '');
            }
            if (el.closest) {
                const parentLabel = el.closest('label');
                if (parentLabel) parts.push(parentLabel.textContent || '');
                const fieldset = el.closest('fieldset');
                if (fieldset) {
                    const legend = fieldset.querySelector('legend');
                    if (legend) parts.push(legend.textContent || '');
                }
            }
        } catch (_) { }
        return parts.join(' ').toLowerCase();
    }

    // 2. Multi-Root Collector (Requirement 5)
    function collectAccessibleRoots(doc = document, maxDepth = 4, maxRoots = 50) {
        const roots = [];
        const crossOriginSignals = [];
        let shadowCount = 0;
        let iframeCount = 0;

        if (!doc) return { roots, crossOriginSignals, shadowCount, iframeCount };
        roots.push(doc);

        function traverse(node, depth) {
            if (!node || depth > maxDepth || roots.length >= maxRoots) return;

            // Collect open shadowRoot
            if (node.shadowRoot) {
                roots.push(node.shadowRoot);
                shadowCount++;
                traverse(node.shadowRoot, depth + 1);
            }

            // Collect iframes
            if (node.tagName === 'IFRAME') {
                iframeCount++;
                try {
                    let ifrDoc = null;
                    try {
                        ifrDoc = node.contentDocument || (node.contentWindow && node.contentWindow.document);
                    } catch (_) {
                        ifrDoc = null;
                    }
                    if (ifrDoc && !roots.includes(ifrDoc)) {
                        roots.push(ifrDoc);
                        traverse(ifrDoc, depth + 1);
                    } else if (!ifrDoc) {
                        // Cross-origin iframe or inaccessible boundary
                        const rawSrc = (node.src || node.getAttribute?.('src') || '').trim();
                        const srcLower = rawSrc.toLowerCase();
                        const title = (node.title || node.getAttribute?.('title') || '').toLowerCase();
                        const idCls = `${node.id || ''} ${node.className || ''}`.toLowerCase();
                        const WIDGET_KEYWORDS = [
                            'contact', 'form', 'hubspot', 'jotform', 'typeform', 'wufoo', 'inquiry',
                            'message', 'pushpress', 'grow', 'lead', 'cognito', 'forms.gle', 'tally',
                            'google.com/forms', 'activecampaign', 'marketo', 'pardot', 'calendly', 'chilipiper'
                        ];
                        const isContactRelated = WIDGET_KEYWORDS.some(k =>
                            srcLower.includes(k) || title.includes(k) || idCls.includes(k)
                        );
                        // Also promote if source is HTTP and not same-origin and not 0x0 hidden pixel
                        const isLikelyExternalForm = isContactRelated || (rawSrc.startsWith('http') && (
                            srcLower.includes('api.') || srcLower.includes('app.') || srcLower.includes('widget') || srcLower.includes('embed')
                        ));
                        if (isLikelyExternalForm || isContactRelated) {
                            crossOriginSignals.push({
                                src: rawSrc,
                                title,
                                reason: 'CROSS_ORIGIN_CONTACT_FORM_DETECTED'
                            });
                        }
                    }
                } catch (_) { }
            }

            // Traverse children
            const children = node.children || [];
            for (let i = 0; i < children.length; i++) {
                traverse(children[i], depth);
            }
        }

        try {
            traverse(doc, 0);
        } catch (_) { }

        return { roots, crossOriginSignals, shadowCount, iframeCount };
    }

    // 3. Body-Field-First Recognition (Requirement 2)
    function findInquiryBodyControls(roots = [document]) {
        const candidates = [];
        const seen = new Set();

        const rootList = Array.isArray(roots) ? roots : [roots];

        for (const root of rootList) {
            if (!root || !root.querySelectorAll) continue;

            // 1. Visible Native Textareas
            try {
                const textareas = Array.from(root.querySelectorAll('textarea'));
                for (const ta of textareas) {
                    if (seen.has(ta)) continue;
                    if (!isVisible(ta) || isHoneypot(ta) || ta.disabled || isExcludedOverlayElement(ta)) continue;
                    const ctx = getControlContext(ta);
                    // Check if strictly newsletter comment only
                    const isNewsletterOnly = NEWSLETTER_NEGATIVE_TOKENS.some(tok => ctx.includes(tok)) &&
                        !INQUIRY_BODY_TOKENS.some(tok => ctx.includes(tok));
                    if (isNewsletterOnly) continue;

                    seen.add(ta);
                    candidates.push({
                        element: ta,
                        type: 'textarea',
                        context: ctx,
                        confidence: 1.0,
                        root
                    });
                }
            } catch (_) { }

            // 2. Visible Contenteditable Controls
            try {
                const editables = Array.from(root.querySelectorAll('[contenteditable="true"], [contenteditable=""]'));
                for (const ed of editables) {
                    if (seen.has(ed)) continue;
                    if (!isVisible(ed) || isHoneypot(ed) || isExcludedOverlayElement(ed)) continue;
                    const ctx = getControlContext(ed);
                    seen.add(ed);
                    candidates.push({
                        element: ed,
                        type: 'contenteditable',
                        context: ctx,
                        confidence: 0.95,
                        root
                    });
                }
            } catch (_) { }

            // 3. ARIA Multiline Textboxes
            try {
                const ariaTextboxes = Array.from(root.querySelectorAll('[role="textbox"][aria-multiline="true"], [role="textbox"]'));
                for (const tb of ariaTextboxes) {
                    if (seen.has(tb)) continue;
                    if (!isVisible(tb) || isHoneypot(tb) || tb.disabled || isExcludedOverlayElement(tb)) continue;
                    const ctx = getControlContext(tb);
                    const isMulti = tb.getAttribute?.('aria-multiline') === 'true' || INQUIRY_BODY_TOKENS.some(k => ctx.includes(k));
                    if (isMulti) {
                        seen.add(tb);
                        candidates.push({
                            element: tb,
                            type: 'aria_textbox',
                            context: ctx,
                            confidence: 0.90,
                            root
                        });
                    }
                }
            } catch (_) { }

            // 4. Multiline or Semantic Text Inputs
            try {
                const textInputs = Array.from(root.querySelectorAll('input:not([type]), input[type="text"]'));
                for (const inp of textInputs) {
                    if (seen.has(inp)) continue;
                    if (!isVisible(inp) || isHoneypot(inp) || inp.disabled || isExcludedOverlayElement(inp)) continue;
                    const ctx = getControlContext(inp);
                    const matchesKeyword = INQUIRY_BODY_TOKENS.some(k => ctx.includes(k));
                    if (matchesKeyword) {
                        seen.add(inp);
                        candidates.push({
                            element: inp,
                            type: 'semantic_input',
                            context: ctx,
                            confidence: 0.85,
                            root
                        });
                    }
                }
            } catch (_) { }
        }

        return candidates;
    }

    // 4. Logical Container Discovery & Control Aggregation
    function inferLogicalContainer(bodyElement) {
        if (!bodyElement) return null;

        // 1. Literal <form> ancestor (highest preference)
        if (typeof bodyElement.closest === 'function') {
            const formTag = bodyElement.closest('form');
            if (formTag) return formTag;
        }

        // 2. Walk upward through ancestors looking for coherent form-like wrappers
        let curr = bodyElement.parentElement;
        let bestNonForm = null;
        let depth = 0;

        while (curr && depth < 8) {
            const tag = (curr.tagName || '').toUpperCase();
            if (tag === 'BODY' || tag === 'HTML') break;

            const id = (typeof curr.id === 'string' ? curr.id : (typeof curr.getAttribute === 'function' ? curr.getAttribute('id') : '') || '').toLowerCase();
            const cls = (typeof curr.className === 'string' ? curr.className : (typeof curr.getAttribute === 'function' ? curr.getAttribute('class') : '') || '').toLowerCase();
            const role = (curr.getAttribute?.('role') || '').toLowerCase();
            const combined = `${id} ${cls} ${role}`;

            const inputCount = curr.querySelectorAll ? curr.querySelectorAll('input, select, textarea').length : 0;

            // Coherent container keywords
            if (
                tag === 'FIELDSET' || role === 'form' ||
                combined.includes('form') || combined.includes('contact') ||
                combined.includes('inquiry') || combined.includes('feedback') ||
                tag === 'SECTION' || tag === 'ARTICLE' || tag === 'MAIN'
            ) {
                // If it only has 1 input or less, it's just a single field wrapper (like preview-form, form-group, form-field, field-holder), NOT the whole form!
                if (inputCount > 1) {
                    bestNonForm = curr;
                    if (combined.includes('contact') || (combined.includes('form') && !combined.includes('preview-form') && !combined.includes('form-group')) || tag === 'FIELDSET' || role === 'form') {
                        return curr;
                    }
                }
            }

            // Fallback: If container contains multiple inputs and a button/submit link, it's a strong candidate
            if (curr.querySelectorAll) {
                const inputs = curr.querySelectorAll('input, select, textarea');
                const btns = curr.querySelectorAll('button, input[type="submit"], [role="button"], a[data-link-type="SUBMIT"], a[data-link-type*="submit" i], a.item-link');
                if (inputs.length >= 2 && btns.length >= 1) {
                    bestNonForm = curr;
                    return curr;
                }
            }

            curr = curr.parentElement;
            depth++;
        }

        return bestNonForm || bodyElement.parentElement;
    }

    // 5. Gather Controls & Evaluate Eligibility (Requirement 3)
    function inspectContainerControls(container) {
        if (!container || !container.querySelectorAll) {
            return {
                names: [], emails: [], phones: [], subjects: [],
                selects: [], checkboxes: [], radios: [], submits: [], allInputs: []
            };
        }

        const allInputs = Array.from(container.querySelectorAll('input, select, textarea, [contenteditable="true"], [role="textbox"], [role="combobox"], [role="checkbox"]')).filter(el => isVisible(el) && !isExcludedOverlayElement(el));

        const names = [];
        const emails = [];
        const phones = [];
        const subjects = [];
        const selects = [];
        const checkboxes = [];
        const radios = [];
        const submits = [];

        for (const el of allInputs) {
            const ctx = getControlContext(el);
            const tag = (el.tagName || '').toUpperCase();
            const type = (el.type || '').toLowerCase();

            if (type === 'email' || ctx.includes('email') || ctx.includes('이메일')) {
                emails.push(el);
            } else if (type === 'tel' || ctx.includes('phone') || ctx.includes('mobile') || ctx.includes('전화') || ctx.includes('연락처')) {
                phones.push(el);
            } else if (ctx.includes('name') || ctx.includes('이름') || ctx.includes('성함')) {
                names.push(el);
            } else if (ctx.includes('subject') || ctx.includes('title') || ctx.includes('제목')) {
                subjects.push(el);
            }

            if (tag === 'SELECT' || el.getAttribute?.('role') === 'combobox') {
                selects.push(el);
            }
            if (type === 'checkbox' || el.getAttribute?.('role') === 'checkbox') {
                checkboxes.push(el);
            }
            if (type === 'radio' || el.getAttribute?.('role') === 'radio') {
                radios.push(el);
            }
        }

        // Submits
        const submitElements = Array.from(container.querySelectorAll('button, input[type="submit"], input[type="button"], [role="button"], a[data-link-type="SUBMIT"], a[data-link-type*="submit" i], a.item-link, a[class*="submit"], a[class*="send"]')).filter(el => isVisible(el) && !isExcludedOverlayElement(el));
        for (const btn of submitElements) {
            const txt = (btn.textContent || btn.value || btn.getAttribute?.('aria-label') || btn.getAttribute?.('data-link-type') || '').toLowerCase().trim();
            // Negative submit filter: login, search, next, cancel, translate
            if (txt.includes('login') || txt.includes('search') || txt.includes('검색') || txt.includes('로그인') || txt.includes('translate') || txt.includes('translation') || txt.includes('번역')) continue;
            submits.push(btn);
        }

        return { names, emails, phones, subjects, selects, checkboxes, radios, submits, allInputs };
    }

    function safeElemAttr(el, attr) {
        if (!el) return '';
        if (typeof el.getAttribute === 'function') {
            const v = el.getAttribute(attr);
            if (typeof v === 'string') return v;
        }
        const prop = attr === 'class' ? el.className : el[attr];
        return typeof prop === 'string' ? prop : '';
    }

    function computeFormSignature(container) {
        if (!container) return 'form_null';
        const id = safeElemAttr(container, 'id');
        const cls = safeElemAttr(container, 'class').slice(0, 40);
        const tag = (container.tagName || 'DIV').toLowerCase();
        let fieldSig = '';
        if (container.querySelectorAll) {
            const inputs = Array.from(container.querySelectorAll('input, textarea, select')).slice(0, 5);
            fieldSig = inputs.map(i => safeElemAttr(i, 'name') || safeElemAttr(i, 'id') || safeElemAttr(i, 'type') || i.tagName).join(',');
        }
        return `${tag}#${id}.${cls}[${fieldSig}]`;
    }

    // 6. FormDiscoveryEngineR2 Class Implementation
    class FormDiscoveryEngineR2 {
        constructor(options = {}) {
            this.options = Object.assign({
                pass1WaitMs: 0,
                pass2WaitMs: 500,
                pass3WaitMs: 900,
                maxWindowMs: 5000,
                logPrefix: '[FORM_SCAN]'
            }, options);
            this.lastDiscoveryResult = null;
        }

        // Framework Fingerprint Detection (R6 Section 6.3)
        detectFrameworkAdapter(container) {
            if (!container) return null;
            const sig = `${safeElemAttr(container, 'id')} ${safeElemAttr(container, 'class')} ${safeElemAttr(container, 'data-form-id')}`.toLowerCase();
            const action = safeElemAttr(container, 'action').toLowerCase();

            if (sig.includes('hs-') || sig.includes('hubspot') || (container.querySelector && container.querySelector('.hs-form, [data-form-id]'))) return 'HubSpot';
            if (sig.includes('gform') || sig.includes('gravity') || (container.querySelector && container.querySelector('.gform_wrapper'))) return 'GravityForms';
            if (sig.includes('wpcf7') || (container.querySelector && container.querySelector('.wpcf7-form'))) return 'ContactForm7';
            if (sig.includes('wpforms') || (container.querySelector && container.querySelector('.wpforms-form'))) return 'WPForms';
            if (sig.includes('ninja') || sig.includes('nf-') || (container.querySelector && container.querySelector('.nf-form-cont'))) return 'NinjaForms';
            if (sig.includes('wix') || (container.querySelector && container.querySelector('[data-testid*="form"], .wixui-form'))) return 'Wix';
            if (sig.includes('sqs-') || sig.includes('squarespace') || (container.querySelector && container.querySelector('.sqs-block-form'))) return 'Squarespace';
            if (sig.includes('w-form') || sig.includes('webflow') || (container.querySelector && container.querySelector('.w-form'))) return 'Webflow';
            if (action.includes('salesforce') || action.includes('pipedrive') || action.includes('activecampaign')) return 'EmbeddedCRM';
            return null;
        }

        // Group & Score Candidates (Requirement 2 & 3, P0 Directive 6732442879)
        groupAndScoreContainers(root = document) {
            const { roots, crossOriginSignals, shadowCount, iframeCount } = collectAccessibleRoots(root);
            const bodyControls = findInquiryBodyControls(roots);

            // [P0 Directive 6732442879] Authoritative tri-state precedence for no-message opt-in
            let includeNoMessage = false;
            if (typeof this.options.includeFormsWithoutMessage === 'boolean') {
                includeNoMessage = this.options.includeFormsWithoutMessage;
            } else if (typeof window !== 'undefined' && typeof window.__xpider_include_forms_without_message === 'boolean') {
                includeNoMessage = window.__xpider_include_forms_without_message;
            }

            const cg = resolveContactGate();
            const scoredContainers = [];
            const evaluatedContainers = new Set();
            let nativeFormCount = 0;
            let logicalContainerCount = 0;

            // 1. Primary ladder: genuine inquiry body controls (textarea, contenteditable, aria-multiline)
            for (const bc of bodyControls) {
                const el = bc.element;
                const container = inferLogicalContainer(el);
                if (!container || evaluatedContainers.has(container) || isExcludedOverlayElement(container)) continue;
                evaluatedContainers.add(container);

                const isNativeForm = container.tagName === 'FORM';
                if (isNativeForm) nativeFormCount++;
                else logicalContainerCount++;

                const controls = inspectContainerControls(container);
                const contactCount = controls.names.length + controls.emails.length + controls.phones.length;
                const submitCount = controls.submits.length;

                // ContactGate strict classification
                let cgRes = null;
                if (cg && typeof cg.classifyFormIntent === 'function') {
                    cgRes = cg.classifyFormIntent(container, {
                        includeFormsWithoutMessage: includeNoMessage,
                        ownerAuthorizedConsent: this.options.ownerAuthorizedConsent,
                        allowAutoConsent: this.options.allowAutoConsent
                    });
                }

                const isOverlay = isExcludedOverlayElement(container);
                const hasValidBody = isVisible(bc.element) && !isExcludedOverlayElement(bc.element);
                const containerContext = `${safeElemAttr(container, 'id')} ${safeElemAttr(container, 'class')}`.toLowerCase();
                const hasInquiryContext = !isOverlay && (isNativeForm || (contactCount >= 1 || submitCount >= 1) ||
                    INQUIRY_BODY_TOKENS.some(k => bc.context.includes(k)) ||
                    containerContext.includes('contact') || containerContext.includes('form') || containerContext.includes('inquiry'));

                // Negative check: Reject newsletter-only forms unless opt-in is active
                const isNewsletterOnly = NEWSLETTER_NEGATIVE_TOKENS.some(tok => containerContext.includes(tok)) &&
                    !INQUIRY_BODY_TOKENS.some(tok => containerContext.includes(tok)) &&
                    controls.allInputs.length <= 2 &&
                    controls.names.length === 0 &&
                    controls.phones.length === 0;

                let eligible = false;
                let reason = 'NO_BODY_FIELD_FOUND';

                if (cgRes) {
                    eligible = Boolean(cgRes.eligible);
                    reason = cgRes.reason;
                } else {
                    eligible = !isOverlay && hasValidBody && hasInquiryContext && (!isNewsletterOnly || includeNoMessage);
                    reason = isOverlay ? 'REJECTED_OVERLAY_CONTAINER'
                        : !hasValidBody ? 'NO_VISIBLE_BODY_FIELD'
                            : !hasInquiryContext ? 'NO_CONTACT_OR_SUBMIT_ASSOCIATED'
                                : (isNewsletterOnly && !includeNoMessage) ? 'REJECTED_NEWSLETTER_ONLY'
                                    : (isNewsletterOnly && includeNoMessage) ? 'ELIGIBLE_NO_MESSAGE_FORM'
                                        : 'ELIGIBLE_INQUIRY_FORM';
                }

                // Logging Requirement 1: [FORM_GATE]
                const candidateSig = computeFormSignature(container);
                console.log(`[FORM_GATE] candidate=${candidateSig} bodyField=${hasValidBody} contactFields=${contactCount} submitters=${submitCount} eligible=${eligible} reason=${reason}`);

                // Scoring is for RANKING only: inquiry forms with textarea prioritized (180+)
                let score = 50;
                if (isNativeForm) score += 50;
                if (bc.type === 'textarea') score += 40;
                if (controls.names.length > 0) score += 20;
                if (controls.emails.length > 0) score += 25;
                if (controls.phones.length > 0) score += 15;
                if (controls.subjects.length > 0) score += 15;
                if (controls.selects.length > 0) score += 10;
                if (controls.checkboxes.length > 0) score += 10;
                if (controls.submits.length > 0) score += 20;

                const adapter = this.detectFrameworkAdapter(container);
                if (adapter) score += 50;

                scoredContainers.push({
                    container,
                    signature: candidateSig,
                    score,
                    eligible,
                    reason,
                    bodyControl: bc,
                    adapter,
                    controls,
                    root: bc.root
                });
            }

            // 2. [P0 Directive 6732442879] Secondary ladder: Candidate form containers without inquiry body (e.g. newsletter/subscribe opt-in)
            // Evaluates accessible form containers across roots; ContactGate strict rules govern eligibility.
            for (const r of roots) {
                if (!r || !r.querySelectorAll) continue;
                const formContainers = Array.from(r.querySelectorAll('form, [role="form"], .form-wrapper, fieldset'));
                for (const container of formContainers) {
                    if (!container || evaluatedContainers.has(container) || isExcludedOverlayElement(container)) continue;
                    evaluatedContainers.add(container);

                    const isNativeForm = container.tagName === 'FORM';
                    if (isNativeForm) nativeFormCount++;
                    else logicalContainerCount++;

                    const controls = inspectContainerControls(container);
                    const contactCount = controls.names.length + controls.emails.length + controls.phones.length;
                    const submitCount = controls.submits.length;

                    let cgRes = null;
                    if (cg && typeof cg.classifyFormIntent === 'function') {
                        cgRes = cg.classifyFormIntent(container, {
                            includeFormsWithoutMessage: includeNoMessage,
                            ownerAuthorizedConsent: this.options.ownerAuthorizedConsent,
                            allowAutoConsent: this.options.allowAutoConsent
                        });
                    }

                    let eligible = false;
                    let reason = 'NO_BODY_FIELD_FOUND';

                    if (cgRes) {
                        eligible = Boolean(cgRes.eligible);
                        reason = cgRes.reason;
                    } else {
                        // Strict fallback when ContactGate is not present
                        const containerContext = `${safeElemAttr(container, 'id')} ${safeElemAttr(container, 'class')}`.toLowerCase();
                        const isNewsletter = NEWSLETTER_NEGATIVE_TOKENS.some(tok => containerContext.includes(tok));
                        const hasVisibleEmail = controls.emails.some(isVisible);
                        if (includeNoMessage && isNewsletter && hasVisibleEmail) {
                            eligible = true;
                            reason = 'ELIGIBLE_NO_MESSAGE_FORM';
                        } else if (isNewsletter) {
                            eligible = false;
                            reason = 'NON_INQUIRY_NEWSLETTER_FORM';
                        } else {
                            eligible = false;
                            reason = 'NO_BODY_FIELD_FOUND';
                        }
                    }

                    const candidateSig = computeFormSignature(container);
                    console.log(`[FORM_GATE] candidate=${candidateSig} bodyField=false contactFields=${contactCount} submitters=${submitCount} eligible=${eligible} reason=${reason}`);

                    // Ranking score: strictly lower than genuine inquiry forms (score <= 120 vs inquiry 180+)
                    let score = 30;
                    if (isNativeForm) score += 30;
                    if (controls.emails.length > 0) score += 25;
                    if (controls.names.length > 0) score += 15;
                    if (controls.submits.length > 0) score += 15;

                    const adapter = this.detectFrameworkAdapter(container);
                    if (adapter) score += 25;

                    scoredContainers.push({
                        container,
                        signature: candidateSig,
                        score,
                        eligible,
                        reason,
                        bodyControl: null,
                        adapter,
                        controls,
                        root: r
                    });
                }
            }

            return {
                candidates: scoredContainers.sort((a, b) => b.score - a.score),
                bodyCount: bodyControls.length,
                nativeFormCount,
                logicalContainerCount,
                shadowCount,
                iframeCount,
                crossOriginSignals,
                rootsCount: roots.length
            };
        }

        // Modal / Drawer Form Reveal Trigger (Requirement 6)
        async dynamicFormReveal(root = document) {
            const { roots } = collectAccessibleRoots(root, 1, 5);
            for (const r of roots) {
                if (!r || !r.querySelectorAll) continue;
                const triggers = Array.from(r.querySelectorAll('button, a, [role="button"], span.btn, .btn'));
                for (const btn of triggers) {
                    if (!isVisible(btn) || btn.disabled) continue;
                    const txt = (btn.textContent || btn.getAttribute?.('aria-label') || btn.value || '').toLowerCase().trim();
                    if (!txt || txt.length > 40) continue;

                    // Safety guard: Must not be destructive or booking/login/subscribe
                    if (DESTRUCTIVE_OR_UNSAFE_KEYWORDS.some(k => txt.includes(k))) continue;

                    const isReveal = SAFE_REVEAL_KEYWORDS.some(k => txt.includes(k));
                    if (isReveal) {
                        try {
                            console.log(`[FORM_REVEAL] Triggering high-confidence contact reveal control: "${txt}"`);
                            if (typeof btn.click === 'function') {
                                btn.click();
                                await new Promise(r => setTimeout(r, 450));
                                return true;
                            }
                        } catch (_) { }
                    }
                }
            }
            return false;
        }

        // Main Multi-Pass Form Discovery Ladder (Requirement 4, 5, 10)
        async discoverForm(root = document) {
            const startTime = Date.now();
            const url = (typeof window !== 'undefined' && window.location ? window.location.href : 'current_page');
            const doc = (root && root.nodeType === 9) ? root : (root && root.ownerDocument) ? root.ownerDocument : (typeof document !== 'undefined' ? document : null);
            if (doc && isPageErrorOr404(doc)) {
                console.warn(`[FORM_SCAN] Aborting discovery: 404/Error page detected url=${url}`);
                this.lastDiscoveryResult = { success: false, reason: 'ERROR_404_PAGE', reasonCode: 'ERROR_404_PAGE', url };
                return null;
            }

            let includeNoMessage = false;
            if (typeof this.options.includeFormsWithoutMessage === 'boolean') {
                includeNoMessage = this.options.includeFormsWithoutMessage;
            } else if (typeof window !== 'undefined' && typeof window.__xpider_include_forms_without_message === 'boolean') {
                includeNoMessage = window.__xpider_include_forms_without_message;
            }

            let totalBodySeen = 0;
            let totalContainersSeen = 0;
            let allCrossOriginSignals = [];

            // Helper to execute a scan pass
            const executePass = (passNum) => {
                const scanRes = this.groupAndScoreContainers(root);
                totalBodySeen = Math.max(totalBodySeen, scanRes.bodyCount);
                totalContainersSeen = Math.max(totalContainersSeen, scanRes.candidates.length);
                if (scanRes.crossOriginSignals && scanRes.crossOriginSignals.length) {
                    allCrossOriginSignals.push(...scanRes.crossOriginSignals);
                }

                // Logging Requirement 1: [FORM_SCAN]
                console.log(`[FORM_SCAN] pass=${passNum} url=${url} roots=${scanRes.rootsCount}`);
                console.log(`[FORM_SCAN] bodyCandidates=${scanRes.bodyCount} nativeForms=${scanRes.nativeFormCount} logicalContainers=${scanRes.logicalContainerCount}`);
                console.log(`[FORM_SCAN] shadowRoots=${scanRes.shadowCount} iframes=${scanRes.iframeCount} modalTriggers=${SAFE_REVEAL_KEYWORDS.length}`);

                const eligibleList = scanRes.candidates.filter(c => c.eligible);
                return { scanRes, eligibleList };
            };

            // === PASS 1: Immediate ===
            let pass1 = executePass(1);
            if (pass1.eligibleList.length > 0) {
                const best = pass1.eligibleList[0];
                this.lastDiscoveryResult = { success: true, container: best.container, signature: best.signature, pass: 1, reason: best.reason, reasonCode: best.reason };
                return best.container;
            }

            // === PASS 2: Settle Wait (400-700ms) ===
            const waitPass2 = this.options.pass2WaitMs;
            if (waitPass2 > 0) {
                await new Promise(r => setTimeout(r, waitPass2));
            }
            let pass2 = executePass(2);
            if (pass2.eligibleList.length > 0) {
                const best = pass2.eligibleList[0];
                this.lastDiscoveryResult = { success: true, container: best.container, signature: best.signature, pass: 2, reason: best.reason, reasonCode: best.reason };
                return best.container;
            }

            // === PASS 3: Bounded Scroll + Modal/Drawer Reveal ===
            if (typeof window !== 'undefined' && typeof window.scrollBy === 'function') {
                try {
                    window.scrollBy({ top: 400, behavior: 'smooth' });
                } catch (_) { }
            }
            await this.dynamicFormReveal(root);

            const waitPass3 = this.options.pass3WaitMs;
            if (waitPass3 > 0) {
                await new Promise(r => setTimeout(r, waitPass3));
            }
            let pass3 = executePass(3);
            if (pass3.eligibleList.length > 0) {
                const best = pass3.eligibleList[0];
                this.lastDiscoveryResult = { success: true, container: best.container, signature: best.signature, pass: 3, reason: best.reason, reasonCode: best.reason };
                return best.container;
            }

            // === Exhaustion: Determine Terminal Failure Code (Requirement 10) ===
            let terminalReason = 'NO_BODY_FIELD_FOUND';
            if (allCrossOriginSignals.length > 0) {
                terminalReason = 'CROSS_ORIGIN_FORM_UNAVAILABLE';
            } else if (totalContainersSeen === 0 && totalBodySeen === 0) {
                terminalReason = 'NO_BODY_FIELD_FOUND';
            } else if (totalBodySeen === 0 && !includeNoMessage) {
                terminalReason = 'NO_BODY_FIELD_FOUND';
            } else if (totalContainersSeen === 0) {
                terminalReason = 'BODY_FIELD_FOUND_CONTAINER_INCOHERENT';
            } else {
                terminalReason = 'FORM_GATE_REJECTED';
            }

            if ((Date.now() - startTime) >= this.options.maxWindowMs) {
                terminalReason = 'FORM_RENDER_TIMEOUT';
            }

            console.log(`[FORM_DISCOVERY_EXHAUSTED] bodyCandidatesSeen=${totalBodySeen} logicalContainersSeen=${totalContainersSeen} eligibleCandidatesSeen=0 reason=${terminalReason}`);

            const primaryCrossOrigin = allCrossOriginSignals.length > 0 ? (allCrossOriginSignals[0].src || null) : null;
            this.lastDiscoveryResult = {
                success: false,
                container: null,
                reason: terminalReason,
                reasonCode: terminalReason,
                bodyCandidatesSeen: totalBodySeen,
                logicalContainersSeen: totalContainersSeen,
                crossOriginSignals: allCrossOriginSignals,
                externalFormUrl: primaryCrossOrigin
            };

            return null;
        }

        // Form Node Replacement / Rebind (Requirement 9)
        rebindFormNode(detachedContainer, signature, root = document) {
            if (!signature) signature = computeFormSignature(detachedContainer);
            const { candidates } = this.groupAndScoreContainers(root);
            for (const cand of candidates) {
                if (cand.signature === signature || (cand.container && computeFormSignature(cand.container) === signature)) {
                    console.log(`[FORM_REBIND] oldDetached=true newFound=true`);
                    return cand.container;
                }
            }
            console.log(`[FORM_REBIND] oldDetached=true newFound=false`);
            return null;
        }
    }

    // 7. Canonical Autofill Bridge (Requirement 7 & 8)
    const _autofillLatches = new Map();

    function startAutofillForEligibleForm(attemptId, formContext, fillExecutor) {
        if (!formContext || !formContext.form) {
            console.log(`[AUTOFILL_BRIDGE_FAILED] reason=FORM_CONTEXT_NULL`);
            return { dispatched: false, reason: 'FORM_CONTEXT_NULL' };
        }

        const formSignature = formContext.signature || computeFormSignature(formContext.form);
        const latchKey = `${attemptId}_${formSignature}`;

        if (_autofillLatches.has(latchKey)) {
            console.log(`[AUTOFILL_BRIDGE] eligibleFormId=${formSignature} dispatched=false reason=ALREADY_DISPATCHED`);
            return { dispatched: false, reason: 'ALREADY_DISPATCHED' };
        }

        _autofillLatches.set(latchKey, Date.now());

        // Latch and dispatch within 250ms
        console.log(`[AUTOFILL_BRIDGE] eligibleFormId=${formSignature} dispatched=true reason=OK`);
        console.log(`[AUTOFILL_START] attemptId=${attemptId} formSignature=${formSignature}`);

        try {
            if (typeof fillExecutor === 'function') {
                fillExecutor(formContext.form, formContext.template, formContext.speed);
            }
            return { dispatched: true, formSignature, reason: 'OK' };
        } catch (err) {
            console.log(`[AUTOFILL_BRIDGE_FAILED] reason=${err.message}`);
            return { dispatched: false, reason: 'AUTOFILL_BRIDGE_FAILED', error: err.message };
        }
    }

    function resetAutofillLatch(attemptId) {
        if (attemptId) {
            for (const k of Array.from(_autofillLatches.keys())) {
                if (k.startsWith(attemptId)) _autofillLatches.delete(k);
            }
        } else {
            _autofillLatches.clear();
        }
    }

    return {
        FormDiscoveryEngineR2,
        FormDiscoveryEngine: FormDiscoveryEngineR2,
        collectAccessibleRoots,
        findInquiryBodyControls,
        inferLogicalContainer,
        inspectContainerControls,
        computeFormSignature,
        startAutofillForEligibleForm,
        resetAutofillLatch
    };
}));
